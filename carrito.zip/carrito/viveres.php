<?php
session_start();
header("Content-Type: text/html;charset=iso-8895-1");
include_once('config.php');
$_SESSION['last_visited_page'] = $_SERVER['PHP_SELF'];
// Verifica si se ha enviado el formulario para añadir al carrito y se ha recibido el código del producto
if(isset($_POST["add_to_cart"]) && isset($_POST["code"])) {


    // Paso 1: Consulta para obtener la información del producto
    $query = "SELECT `ProductoID`, P.`Nombre`, `Precio`, `RutaImagen`, `RutaImagenThumb`, `PagaIVA`, `Descuento`  
              FROM Producto P, ProductoTipo T WHERE P.ProductoTipoID = T.ProductoTipoID AND ProductoID = ?";
              
    if($stmt = mysqli_prepare($conn, $query)) {
        
        mysqli_stmt_bind_param($stmt, "s", $codigoProducto);
        $codigoProducto = $_POST["code"];        

        if(mysqli_stmt_execute($stmt)) {
            mysqli_stmt_bind_result($stmt,
                $ProductoID,
                $ProductoNombre,                                       
                $ProductoPrecio,                                       
                $ProductoRutaImagen,
                $ProductoRutaImagenThumb,
                $ProductoPagaIVA,
                $ProductoDescuento
            );
                                   
            // Paso 2: Almacena la información del producto en un array
            while (mysqli_stmt_fetch($stmt)) {
                $itemProducto = array(
                    'ProductoID' => $ProductoID,
                    'Nombre' => $ProductoNombre,
                    'Precio' => $ProductoPrecio,
                    'Imagen' => $ProductoRutaImagen,
                    'ImagenThumb' => $ProductoRutaImagenThumb,
                    'Cantidad' => $_POST["cantidad"], // La cantidad viene del formulario
                    'PagaIVA' => $ProductoPagaIVA,
                    'Descuento' => $ProductoDescuento
                );
            }                
        }
        else {
            echo "ERROR: No se pudo ejecutar la consulta: " . mysqli_error($conn);
        }            
        mysqli_stmt_close($stmt);            
    }
    else {
        die("<pre>".mysqli_error($conn) . PHP_EOL . $query."</pre>");
    }
                                                
    $status="";        

    // Paso 3: Procesar la acción según el botón presionado ("action")
    switch($_POST["action"]) {
        case "agregar":
            $itemArray = array(
                $itemProducto['ProductoID'] => array(
                    'ProductoID' => $itemProducto['ProductoID'],
                    'Nombre' => $itemProducto['Nombre'],
                    'Precio' => $itemProducto['Precio'],
                    'Imagen' => $itemProducto['Imagen'],
                    'ImagenThumb' => $itemProducto['ImagenThumb'],
                    'Cantidad' => $_POST["cantidad"], // La cantidad viene del formulario
                    'PagaIVA' => $itemProducto['PagaIVA'],
                    'Descuento' => $itemProducto['Descuento']
                )
            );

            // Paso 4: Añadir el producto al carrito
            if(empty($_SESSION["shopping_cart"])) {
                // 4.1 Si el carrito está vacío
                $_SESSION["shopping_cart"] = $itemArray;
                $_SESSION["message"] = "El producto ha sido añadido al carrito de compras";
            }
            else {
                // 4.2 Si el carrito no está vacío
                $array_keys = array_keys($_SESSION["shopping_cart"]);
                if(in_array($itemProducto['ProductoID'], $array_keys)) {
                    // 4.2.1 Si el producto ya está en el carrito, aumenta la cantidad
                    $_SESSION["shopping_cart"][$itemProducto['ProductoID']]["Cantidad"] += $_POST["cantidad"];
                    $_SESSION["message"] = "El producto ha sido añadido al carrito de compras";
                } 
                else {
                    // 4.2.2 Si el producto no está en el carrito, añádelo como un nuevo ítem
                    $_SESSION["shopping_cart"][$itemProducto['ProductoID']] = $itemArray[$itemProducto['ProductoID']];
                }
                $_SESSION["message"] = "El producto ha sido añadido al carrito de compras";
            }
            break;
    }
    header("Location: carrito.php");
    exit();
}
?>
					
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsiveslides.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="js/ResponsiveSlides.js"></script>		
    <script src="js/responsiveslides.min.js"></script>

    <script>
        $(function() {
            $(".rslides").responsiveSlides();
        });

        $(document).ready(function(){
            <?php if(isset($_SESSION["message"])): ?>
                <?php unset($_SESSION["message"]); ?>
                
                alert('<?php echo $_SESSION["message"]; ?>');
            <?php endif; ?>
        });
    </script>

    <style>
        .gallery {
            display: flex;
            flex-wrap: wrap;
        }
        .image-container {
            width: 23%;
            margin: 1%;
            text-align: center;
            border: solid 2px #2d406e;
            padding: 20px;
            margin-top: 102px;
            background-color: #f5f5dc;
        }
        .container form img {
            width: auto;
            margin: 18px 45px;
            border: solid 2px #2d406e;
            height: auto;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <div class="navbar-container">
                <h1>Carrito de Compras</h1>
                <ul class="nav-menu">
                    <li><a href="viveres.php">Inicio</a></li>
                    <li><a href="#contacto">Contáctenos</a></li>
                    <?php
						if (!empty($_SESSION["shopping_cart"])) {
                            $cart_count = array_sum(array_column($_SESSION["shopping_cart"], 'Cantidad'));
                            ?>
                            <li>
                                <a href="carrito.php"><img src="images/carrito.png" /> Carrito <span>
                                    <?php echo $cart_count; ?></span></a>
                            </li>
						<?php } 
					?>
                </ul>
            </div>
        </nav>
    </header>
    <div>
    <ul class="rslides">
        <li><img src="imagenes_banner/uno.png" alt=""></li>
        <li><img src="imagenes_banner/dos.png" alt=""></li>
        <li><img src="imagenes_banner/tres.png" alt=""></li>
        <li><img src="imagenes_banner/cuatro.png" alt=""></li>
      </ul>
    </div>

    <header>
    <div class="navbar-container">
    <ul class="nav">
                    <li><a href="viveres.php" style="font-size: 16px !important; width: 100%;">Viveres</a></li>
                    <li><a href="limpieza.php" style="font-size: 16px !important; width: 100%;">Limpieza</a></li>
                    <li><a href="bebidas.php" style="font-size: 16px; width: 100%;">Bebidas</a></li>
					<li><a href="snacks.php" style="font-size: 16px; width: 100%;">Snacks</a></li>
					<li><a href="aseo.php" style="font-size: 16px; width: 100%;">Aseo Personal</a></li>
    </ul>
    <div>
    </header>																		
	<?php					
		$ProductoID = null; $RutaImagen = null; $Cantidad = 0; $Nombre = null; $contador = 0; $precioFinal = 0;				
		$sql = "SELECT P.ProductoID, P.RutaImagen, P.Nombre, P.Precio, P.Descuento FROM Producto P, ProductoTipo T
				WHERE P.ProductoTipoID = T.ProductoTipoID AND P.ProductoCategoriaID = 1 AND P.Activo = 1 ORDER BY P.Orden";	
		$resultset = mysqli_query($conn, $sql) or die("database error:". mysqli_error($conn));		
		while( $record = mysqli_fetch_assoc($resultset) ) {
			$contador += 1;							
	?>					
			<div class="col-md-3" style="border: solid 2px #2d406e; margin: 35px; width: 15%; background-color: #f5f5dc;" >
				<div>
				<center><div class="container" style="width: 0px;">																
						<center><img src="<?php echo $record['RutaImagen']; ?>" alt=""></center>
					</div>								
					<div>																										
						<form method="post" action="viveres.php">
							<input type="hidden" name="code" value="<?php echo $record['ProductoID']; ?>" />
							<input type="hidden" name="action" value="agregar" />
							<input type="hidden" name="viveres"></input>																			
							<div class="productoMarca"><?php echo $record['Nombre']; ?></div>																												
							<div class="productoPrecio"><?php echo '$' . number_format((float)$record['Precio'], 2, '.', '') ?> </div>										
																								
							<div style="margin: 0 auto; width: 40px; padding: 10px 0px 10px 0px;">
								<input type="text" class="product-quantity" name="cantidad" value="1" size="2" style="border: solid 1px #a7a7b3;" />
							</div>
							<input type="submit" style="align-items: center;" class="btn btn-primary btnGuardar " name="add_to_cart" value="A&ntilde;adir a carrito"/>
						</form>
						</center></div>
				</div>														
			</div>
		
			<?php
			if(($contador % 4) == 0 ){						
				echo '<div style="clear: both;"></div>';
			}
			?>
		<?php
		}
		?>				

    <?php
    // Mostrar el mensaje si está definido
    if(isset($_SESSION["message"])) {
        echo "<div class='alert alert-success'>" . $_SESSION["message"] . "</div>";
        // Eliminar el mensaje después de mostrarlo
        unset($_SESSION["message"]);
    }
    ?>
</div>
</body>        
</html>