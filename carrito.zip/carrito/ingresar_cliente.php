<?php
    header("Content-Type: application/json; charset=utf-8");
	include_once('config.php');

	$clienteCedula = $_POST['cliente_cedula'];
	$clienteNombre = $_POST['cliente_Nombre'];
	$clienteApellido = $_POST['cliente_Apellido'];
	$suscriptorSector = $_POST['suscriptorSector'];
	$clienteTelefono = $_POST['cliente_Telefono'];
	$clienteCelular = $_POST['cliente_Celular'];
	$clienteEmail = $_POST['cliente_Email'];

	$conn->query("SET NAMES utf8");

	$sql = "INSERT INTO cliente (Cedula, Nombre, SectorID, Apellido, Telefono, Celular, Email, FechaCreacion, FechaActualizacion)
	        VALUES ('$clienteCedula', '$clienteNombre', '$clienteApellido', '$suscriptorSector', '$clienteTelefono', '$clienteCelular', '$clienteEmail', NOW(), NOW())";

	if (mysqli_query($conn, $sql)) {
		echo json_encode(["status" => "success"]);
	} else {
		echo json_encode(["status" => "error", "message" => mysqli_error($conn)]);
	}

	mysqli_close($conn);
?>
