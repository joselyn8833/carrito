-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-07-2024 a las 05:53:49
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `carrito`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `ClienteID` int(11) NOT NULL,
  `Cedula` varchar(13) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '9999999999',
  `Nombre` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `SectorID` int(11) NOT NULL,
  `Apellido` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Telefono` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Celular` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Email` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `FechaCreacion` datetime NOT NULL,
  `FechaActualizacion` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`ClienteID`, `Cedula`, `Nombre`, `SectorID`, `Apellido`, `Telefono`, `Celular`, `Email`, `FechaCreacion`, `FechaActualizacion`) VALUES
(0, '1722323928', 'joselyn', 0, '36', '026864689', '0979363036', 'joselyn.gmail.com', '2024-07-04 22:41:35', '2024-07-04 22:41:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `impuestotarifa`
--

CREATE TABLE `impuestotarifa` (
  `ImpuestoTarifaID` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Sigla` varchar(8) NOT NULL,
  `Valor` decimal(10,2) NOT NULL,
  `Descripcion` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `impuestotarifa`
--

INSERT INTO `impuestotarifa` (`ImpuestoTarifaID`, `Nombre`, `Sigla`, `Valor`, `Descripcion`) VALUES
(1, 'IVA', 'IVA', 12.00, 'IVA del producto'),
(2, 'Tarjeta de débito', 'TD', 2.24, 'Tarifa bancaria para pago con tarjeta de débito (incluye IVA).'),
(3, 'Tarjeta de crédito corriente', 'TCCC', 4.50, 'Tarifa bancaria para pago con tarjeta de crédito en crédito corriente (incluye IVA).');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido`
--

CREATE TABLE `pedido` (
  `PedidoID` int(11) NOT NULL,
  `SesionID` varchar(14) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ClienteID` int(11) NOT NULL,
  `Fecha` datetime NOT NULL,
  `PagoTipoID` int(11) NOT NULL,
  `PedidoEstadoID` int(11) NOT NULL,
  `SectorID` int(11) NOT NULL,
  `Barrio` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Descuento` decimal(10,0) NOT NULL,
  `PedidoValorTotal` decimal(10,0) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;

--
-- Volcado de datos para la tabla `pedido`
--

INSERT INTO `pedido` (`PedidoID`, `SesionID`, `ClienteID`, `Fecha`, `PagoTipoID`, `PedidoEstadoID`, `SectorID`, `Barrio`, `Descuento`, `PedidoValorTotal`) VALUES
(1, '20200402233808', 1, '2024-04-02 23:38:39', 1, 1, 0, 'San Fernando', 3, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidodetalle`
--

CREATE TABLE `pedidodetalle` (
  `PedidoDetalleID` int(11) NOT NULL,
  `PedidoID` int(11) NOT NULL,
  `ProductoID` int(11) NOT NULL,
  `Cantidad` int(11) NOT NULL,
  `Precio` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;

--
-- Volcado de datos para la tabla `pedidodetalle`
--

INSERT INTO `pedidodetalle` (`PedidoDetalleID`, `PedidoID`, `ProductoID`, `Cantidad`, `Precio`) VALUES
(1, 1, 1, 1, 52),
(2, 1, 2, 1, 54),
(3, 1, 3, 1, 51),
(4, 1, 4, 1, 59),
(5, 1, 5, 1, 10),
(6, 1, 6, 1, 16),
(7, 1, 7, 1, 7),
(8, 1, 8, 1, 5),
(9, 1, 9, 1, 29);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidoestado`
--

CREATE TABLE `pedidoestado` (
  `PedidoEstadoID` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `pedidoestado`
--

INSERT INTO `pedidoestado` (`PedidoEstadoID`, `Nombre`) VALUES
(1, 'Registrado'),
(2, 'Pagado'),
(3, 'Entregado'),
(4, 'Reversado'),
(5, 'Devuelto');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `ProductoID` int(11) NOT NULL,
  `ProductoCategoriaID` int(11) NOT NULL,
  `ProductoTipoID` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Precio` double NOT NULL,
  `FechaUltimoPrecio` date NOT NULL,
  `Descuento` int(11) NOT NULL,
  `Activo` tinyint(1) NOT NULL,
  `RutaImagen` varchar(200) NOT NULL,
  `RutaImagenThumb` varchar(200) NOT NULL,
  `PagaIVA` tinyint(4) NOT NULL,
  `Orden` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`ProductoID`, `ProductoCategoriaID`, `ProductoTipoID`, `Nombre`, `Precio`, `FechaUltimoPrecio`, `Descuento`, `Activo`, `RutaImagen`, `RutaImagenThumb`, `PagaIVA`, `Orden`) VALUES
(1, 3, 6, 'Coca_Cola', 1.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/bebidas/coca_cola.png', 'images/productos/checkout/bebidas/coca_cola.png', 1, 1),
(2, 3, 6, 'Pepsi', 1.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/bebidas/pepsi.png', 'images/productos/checkout/bebidas/pepsi.png', 1, 2),
(3, 3, 6, 'Fanta', 1.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/bebidas/fanta.png', 'images/productos/checkout/bebidas/fanta.png', 1, 3),
(4, 3, 6, 'Sprite', 1.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/bebidas/sprite.png', 'images/productos/checkout/bebidas/sprite.png', 1, 4),
(5, 3, 7, 'Mountain_Dew', 1.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/bebidas/mountain_dew.png', 'images/productos/checkout/bebidas/mountain_dew.png', 1, 5),
(6, 3, 7, 'Red Bull', 2.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/bebidas/red_bull.png', 'images/productos/checkout/bebidas/red-bull.png', 1, 6),
(7, 3, 7, 'Monster_Energy', 2.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/bebidas/monster.png', 'images/productos/checkout/bebidas/monster.png', 1, 7),
(8, 3, 7, 'Gatorade', 1.75, '2024-06-21', 0, 1, 'images/productos/thumbnails/bebidas/gatorade.png', 'images/productos/checkout/bebidas/gatorade.png', 1, 8),
(9, 3, 7, 'Powerade', 1.75, '2024-06-21', 0, 1, 'images/productos/thumbnails/bebidas/powerade.png', 'images/productos/checkout/bebidas/powerade.png', 1, 9),
(10, 3, 8, 'Nestea', 1.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/bebidas/nestea.png', 'images/productos/checkout/bebidas/nestea.png', 1, 10),
(11, 2, 1, 'Deja', 3.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/limpiezaAseo/deja.png', 'images/productos/checkout/limpiezaAseo/deja.png', 1, 1),
(12, 2, 2, 'Lava', 2.75, '2024-06-21', 0, 1, 'images/productos/thumbnails/limpiezaAseo/lava.png', 'images/productos/checkout/limpiezaAseo/lava.png', 1, 2),
(13, 2, 3, 'Windex', 2.25, '2024-06-21', 0, 1, 'images/productos/thumbnails/limpiezaAseo/windex.png', 'images/productos/checkout/limpiezaAseo/windex.png', 1, 3),
(14, 2, 4, 'Tips', 3, '2024-06-21', 0, 1, 'images/productos/thumbnails/limpiezaAseo/tips.png', 'images/productos/checkout/limpiezaAseo/tips.png', 1, 4),
(15, 2, 5, 'Serenia', 4, '2024-06-21', 0, 1, 'images/productos/thumbnails/limpiezaAseo/serenia.png', 'images/productos/checkout/limpiezaAseo/serenia.png', 1, 5),
(16, 2, 9, 'Orion', 2.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/limpiezaAseo/orion.png', 'images/productos/checkout/limpiezaAseo/orion.png', 1, 6),
(17, 2, 10, 'Clorox', 1.75, '2024-06-21', 0, 1, 'images/productos/thumbnails/limpiezaAseo/clorox.png', 'images/productos/checkout/limpiezaAseo/clorox.png', 1, 7),
(18, 2, 11, 'Tips', 2, '2024-06-21', 0, 1, 'images/productos/thumbnails/limpiezaAseo/tips_1.png', 'images/productos/checkout/limpiezaAseo/tips_1.png', 1, 8),
(19, 2, 12, 'Palmolive', 1.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/limpiezaAseo/palmolive.png', 'images/productos/checkout/limpiezaAseo/palmolive.png', 1, 9),
(20, 2, 4, 'Sanytol', 3.25, '2024-06-21', 0, 1, 'images/productos/thumbnails/limpiezaAseo/sanytol.png', 'images/productos/checkout/limpiezaAseo/sanytol.png', 1, 10),
(21, 4, 14, 'ruffles', 1.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/snacks/ruffles.png', 'images/productos/checkout/snacks/ruffles.png', 1, 1),
(22, 4, 14, 'dorito', 2, '2024-06-21', 0, 1, 'images/productos/thumbnails/snacks/dorito.png', 'images/productos/checkout/snacks/dorito.png', 1, 2),
(23, 4, 14, 'tostitos', 1.75, '2024-06-21', 0, 1, 'images/productos/thumbnails/snacks/tostitos.png', 'images/productos/checkout/snacks/tostitos.png', 1, 3),
(24, 4, 13, 'choco_break', 2.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/snacks/choco_break.png', 'images/productos/checkout/snacks/choco_break.png', 1, 4),
(25, 4, 13, 'ferrero', 0.75, '2024-06-21', 0, 1, 'images/productos/thumbnails/snacks/ferrero.png', 'images/productos/checkout/snacks/ferrero.png', 1, 5),
(26, 4, 13, 'mym', 2.25, '2024-06-21', 0, 1, 'images/productos/thumbnails/snacks/mym.png', 'images/productos/checkout/snacks/mym.png', 1, 6),
(27, 4, 13, 'nestle', 3, '2024-06-21', 0, 1, 'images/productos/thumbnails/snacks/nestle.png', 'images/productos/checkout/snacks/nestle.png', 1, 7),
(28, 4, 15, 'agogo', 1.25, '2024-06-21', 0, 1, 'images/productos/thumbnails/snacks/agogo.png', 'images/productos/checkout/snacks/agogo.png', 1, 8),
(29, 4, 16, 'energy_bar', 2.75, '2024-06-21', 0, 1, 'images/productos/thumbnails/snacks/energy_bar.png', 'images/productos/checkout/snacks/energy_bar.png', 1, 9),
(30, 4, 17, 'krizpiz', 1.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/snacks/krizpiz.png', 'images/productos/checkout/snacks/krizpiz.png', 1, 10),
(31, 5, 22, 'yellow', 3.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/aseoPersonal/yellow.png', 'images/productos/checkout/aseoPersonal/yellow.png', 1, 1),
(32, 5, 20, 'protex', 1, '2024-06-21', 0, 1, 'images/productos/thumbnails/aseoPersonal/protex.png', 'images/productos/checkout/aseoPersonal/protex.png', 1, 2),
(33, 5, 19, 'colgate', 2, '2024-06-21', 0, 1, 'images/productos/thumbnails/aseoPersonal/colgate.png', 'images/productos/checkout/aseoPersonal/colgate.png', 1, 3),
(34, 5, 18, 'axe', 2.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/aseoPersonal/axe.png', 'images/productos/checkout/aseoPersonal/axe.png', 1, 4),
(35, 5, 18, 'dove', 5, '2024-06-21', 0, 1, 'images/productos/thumbnails/aseoPersonal/dove.png', 'images/productos/checkout/aseoPersonal/dove.png', 1, 5),
(36, 5, 18, 'gillette', 4, '2024-06-21', 0, 1, 'images/productos/thumbnails/aseoPersonal/gillette.png', 'images/productos/checkout/aseoPersonal/gillette.png', 1, 6),
(37, 5, 18, 'nivea', 2.75, '2024-06-21', 0, 1, 'images/productos/thumbnails/aseoPersonal/nivea.png', 'images/productos/checkout/aseoPersonal/nivea.png', 1, 7),
(38, 5, 18, 'speed', 3, '2024-06-21', 0, 1, 'images/productos/thumbnails/aseoPersonal/speed.png', 'images/productos/checkout/aseoPersonal/speed.png', 1, 8),
(39, 5, 21, 'lucian', 3.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/aseoPersonal/lucian.png', 'images/productos/checkout/aseoPersonal/lucian.png', 1, 9),
(40, 5, 21, 'sauvage', 1.75, '2024-06-21', 0, 1, 'images/productos/thumbnails/aseoPersonal/sauvage.png', 'images/productos/checkout/aseoPersonal/sauvage.png', 1, 10),
(41, 1, 23, 'Conejo 100lb', 52, '2024-06-13', 0, 1, 'images/productos/thumbnails/alimentos/arroz_conejo.png', 'images/productos/checkout/alimentos/arroz_conejo.png', 0, 1),
(42, 1, 23, 'Floral Capirona 100lb', 54, '2024-06-13', 0, 1, 'images/productos/thumbnails/alimentos/arroz_florestal.png', 'images/productos/checkout/alimentos/arroz_florestal.png', 0, 2),
(43, 1, 23, 'Gallito Reventón 100lb', 51, '2024-06-13', 0, 1, 'images/productos/thumbnails/alimentos/arroz_gallito.png', 'images/productos/checkout/alimentos/arroz_gallito.png', 0, 3),
(44, 1, 23, 'Monterrey 45kg', 59, '2024-06-13', 0, 1, 'images/productos/thumbnails/alimentos/azucar_monterrey.png', 'images/productos/checkout/alimentos/azucar_monterrey.png', 0, 4),
(45, 1, 25, 'Regia 3kg', 9.68, '2024-06-13', 0, 1, 'images/productos/thumbnails/alimentos/margarina_regia_3kg.png', 'images/productos/checkout/alimentos/margarina_regia_3kg.png', 0, 4),
(46, 1, 23, 'casa_del_arrg', 1.2, '2024-06-21', 0, 1, 'images/productos/thumbnails/alimentos/casa_del_arrg.png', 'images/productos/checkout/alimentos/casa_del_arrg.png', 1, 1),
(47, 1, 24, 'patrona', 1.5, '2024-06-21', 0, 1, 'images/productos/thumbnails/alimentos/patrona.png', 'images/productos/checkout/alimentos/patrona.png', 1, 2),
(48, 1, 25, 'azucar_blanca', 1.8, '2024-06-21', 0, 1, 'images/productos/thumbnails/alimentos/azucar_blanca.png', 'images/productos/checkout/alimentos/azucar_blanca.png', 1, 3),
(49, 1, 25, 'valdez', 3, '2024-06-21', 0, 1, 'images/productos/thumbnails/alimentos/valdez.png', 'images/productos/checkout/alimentos/valdez.png', 1, 4),
(50, 1, 26, 'tababuela', 2, '2024-06-21', 0, 1, 'images/productos/thumbnails/alimentos/tababuela.png', 'images/productos/checkout/alimentos/tababuela.png', 1, 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productocategoria`
--

CREATE TABLE `productocategoria` (
  `ProductoCategoriaID` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `productocategoria`
--

INSERT INTO `productocategoria` (`ProductoCategoriaID`, `Nombre`) VALUES
(1, 'Alimentos'),
(2, 'Limpieza'),
(3, 'Bebidas'),
(4, 'Snacks'),
(5, 'Aseo personal');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productotipo`
--

CREATE TABLE `productotipo` (
  `ProductoTipoID` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Etiqueta` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `productotipo`
--

INSERT INTO `productotipo` (`ProductoTipoID`, `Nombre`, `Etiqueta`) VALUES
(1, 'Detergente', 'En polvo'),
(2, 'Lavavajillas', 'En crema'),
(3, 'Limpiador ', 'Liquido'),
(4, 'Desinfectante', 'Liquido'),
(5, 'Suavizante', 'Liquido'),
(6, 'Gaseosa', 'Cola'),
(7, 'Energizante', 'Energizante'),
(8, 'Refresco', 'Refresco'),
(9, 'Limpiador', 'Liquido'),
(10, 'Cloro', 'Liquido'),
(11, 'Ambientador', 'Ambientador'),
(12, 'Jabon de manos', 'Liquido'),
(13, 'Chocolates', 'De funda '),
(14, 'Papas', 'De funda'),
(15, 'Chicles', 'De funda'),
(16, 'Galletas ', 'De funda '),
(17, 'Barra', 'Energetica'),
(18, 'Desodorante ', 'De barra'),
(19, 'Pasta dental', 'Pasta dental'),
(20, 'Jabon', 'De mano'),
(21, 'Perfume', ''),
(22, 'Shampoo', 'Liquido'),
(23, 'Arroz blanco', 'Arroz blanco'),
(24, 'Azúcar blanca', 'Azúcar blanca'),
(25, 'Margarina vegetal', 'Margarina vegetal'),
(26, 'Azúcar morena', 'Azúcar morena');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sector`
--

CREATE TABLE `sector` (
  `SectorID` int(11) NOT NULL,
  `Nombres` varchar(100) NOT NULL,
  `ZonaID` int(11) NOT NULL,
  `Costo` decimal(2,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `sector`
--

INSERT INTO `sector` (`SectorID`, `Nombres`, `ZonaID`, `Costo`) VALUES
(1, 'Cutuglahua', 1, 8),
(2, 'Turubamba', 1, 7),
(3, 'Guamaní', 1, 7),
(4, 'La Ecuatoriana', 1, 7),
(5, 'Quitumbe', 1, 7),
(6, 'Chillogallo', 1, 7),
(7, 'La Mena', 1, 6),
(8, 'Solanda', 1, 6),
(9, 'La Argelia', 1, 6),
(10, 'San Bartolo', 1, 6),
(11, 'La Ferroviaria', 1, 6),
(12, 'Chilibulo', 1, 6),
(13, 'La Magdalena', 1, 4),
(14, 'Chimbacalle', 1, 5),
(15, 'Puengasí', 1, 5),
(16, 'La Libertad', 2, 6),
(17, 'Centro Histórico', 2, 6),
(18, 'Itchimbía', 2, 6),
(19, 'San Juan', 2, 7),
(20, 'Mariscal Sucre', 3, 7),
(21, 'Belisario Quevedo', 3, 7),
(22, 'Rumipamba', 3, 7),
(23, 'Iñaquito', 3, 8),
(24, 'Jipijapa', 3, 8),
(25, 'Cochapamba', 3, 8),
(26, 'La Concepción', 3, 8),
(27, 'La Kennedy', 3, 8),
(28, 'El Inca', 3, 8),
(29, 'Cotocollao', 3, 8),
(30, 'Ponceano', 3, 8),
(31, 'Comité del Pueblo', 3, 8),
(32, 'El Condado', 3, 8),
(33, 'Carcelén', 3, 8),
(34, 'Llano Chico', 3, 9),
(35, 'Llano Grande', 3, 9),
(36, 'Calderón', 3, 10),
(37, 'Pomasqui', 3, 12),
(38, 'Guangopolo', 4, 6),
(39, 'Conocoto', 4, 6),
(40, 'Alangasí', 4, 9),
(41, 'San Rafael', 4, 7),
(42, 'Sangolquí', 4, 8),
(43, 'Cumbayá', 5, 10),
(44, 'Tumbaco', 5, 10),
(45, 'Puembo', 5, 12),
(46, 'Yaruquí', 5, 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tablasecuencial`
--

CREATE TABLE `tablasecuencial` (
  `TablaSecuencialID` int(11) NOT NULL,
  `Tabla` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Valor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci ROW_FORMAT=COMPACT;

--
-- Volcado de datos para la tabla `tablasecuencial`
--

INSERT INTO `tablasecuencial` (`TablaSecuencialID`, `Tabla`, `Valor`) VALUES
(1, 'Cliente', 1),
(2, 'Pedido', 1),
(3, 'PedidoDetalle', 1),
(4, 'Sucriptor', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zona`
--

CREATE TABLE `zona` (
  `ZonaID` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `CostoEntrega` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `zona`
--

INSERT INTO `zona` (`ZonaID`, `Nombre`, `CostoEntrega`) VALUES
(1, 'Sur', 5),
(2, 'Centro', 4),
(3, 'Norte', 3),
(4, 'Valle de los Chillos', 4),
(5, 'Valle de Tumbaco', 4);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`ClienteID`);

--
-- Indices de la tabla `impuestotarifa`
--
ALTER TABLE `impuestotarifa`
  ADD PRIMARY KEY (`ImpuestoTarifaID`);

--
-- Indices de la tabla `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`PedidoID`);

--
-- Indices de la tabla `pedidoestado`
--
ALTER TABLE `pedidoestado`
  ADD PRIMARY KEY (`PedidoEstadoID`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`ProductoID`);

--
-- Indices de la tabla `productocategoria`
--
ALTER TABLE `productocategoria`
  ADD PRIMARY KEY (`ProductoCategoriaID`);

--
-- Indices de la tabla `productotipo`
--
ALTER TABLE `productotipo`
  ADD PRIMARY KEY (`ProductoTipoID`);

--
-- Indices de la tabla `sector`
--
ALTER TABLE `sector`
  ADD PRIMARY KEY (`SectorID`);

--
-- Indices de la tabla `tablasecuencial`
--
ALTER TABLE `tablasecuencial`
  ADD PRIMARY KEY (`TablaSecuencialID`);

--
-- Indices de la tabla `zona`
--
ALTER TABLE `zona`
  ADD PRIMARY KEY (`ZonaID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
