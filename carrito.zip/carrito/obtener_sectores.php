<?php
    header("Content-Type: text/html; charset=utf-8");
	include_once('config.php');

	$zonaID = $_GET['codigo'];

	$conn->query("SET NAMES utf8");
	$sql = "SELECT SectorID, Nombres FROM sector WHERE ZonaID = " . $zonaID;

	$result = mysqli_query($conn, $sql);

	while($row = mysqli_fetch_array($result)) {
		echo '<option value="'.$row['SectorID'].'">' . $row['Nombres'] . "</option>";
	}

	mysqli_free_result($result);
	mysqli_close($conn);
?>
