<?php
	ini_set('display_errors', 1);
	error_reporting(E_ALL);
	
	$server   = "localhost";
	$database = "carrito";	
	$username = "root";	
	$password = "";
			
	$conn = mysqli_connect($server, $username, $password, $database);
	if (!$conn) {
		die('No se puede conectar con la BDD : ' . mysqli_error());		
	}
	// else{
		// echo "Connected successfully";
	// }	
?>