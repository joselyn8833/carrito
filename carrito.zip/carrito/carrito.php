<?php
session_start();
header("Content-Type: text/html;charset=utf-8");
include_once('config.php');

// Procesar la actualización de cantidad
if (isset($_POST["update_quantity"])) {
    $productID = $_POST["product_id"];
    $quantity = $_POST["quantity"];
    if (isset($_SESSION["shopping_cart"][$productID])) {
        $_SESSION["shopping_cart"][$productID]["Cantidad"] = $quantity;
    }
}

// Procesar la eliminación de producto
if (isset($_POST["delete_product"])) {
    $productID = $_POST["product_id"];
    if (isset($_SESSION["shopping_cart"][$productID])) {
        unset($_SESSION["shopping_cart"][$productID]);
    }
}
// Verificar si hay productos en el carrito
$productos = isset($_SESSION['shopping_cart']) ? $_SESSION['shopping_cart'] : array();

// Calcular el total del pedido
$totalPedido = calcularTotalPedido($productos);

function calcularTotalPedido($productos) {
    $subtotalIVA15 = 0;
    $subtotalIVA0 = 0;
    $totalIVA = 0;

    foreach ($productos as $producto) {
        $subtotal = $producto['Cantidad'] * $producto['Precio'];
        $iva = ($producto['PagaIVA']) ? ($subtotal * 0.15) : 0;
        if ($producto['PagaIVA']) {
            $subtotalIVA15 += $subtotal;
        } else {
            $subtotalIVA0 += $subtotal;
        }
        $totalIVA += $iva;
    }

    $totalPedido = $subtotalIVA15 + $subtotalIVA0 + $totalIVA;

    // Asumiendo que hay un costo fijo de entrega
    $costoEntrega = obtenerCostoEntrega(); // Implementar función para obtener el costo de entrega

    $totalPedido += $costoEntrega;

    return $totalPedido;
}

// Función ficticia para obtener el costo de entrega
function obtenerCostoEntrega() {
    // Implementación ficticia, puedes adaptarla según tu lógica de negocio
    $costoEntrega = 5; // Supongamos un costo fijo por entrega
    return $costoEntrega;
}

// Función para guardar la información del pedido en la base de datos
function guardarPedidoEnBD($productos, $totalPedido) {
    // Implementar lógica para guardar en la base de datos
    // Por simplicidad, se simula la inserción y obtención del número de pedido
    $numeroPedido = mt_rand(1000, 9999); // Generar número de pedido aleatorio (simulado)

    // Aquí se debería insertar en la base de datos y obtener el número de pedido real
    // Ejemplo ficticio:
    // mysqli_query($conn, "INSERT INTO pedidos (total_pedido) VALUES ($totalPedido)");
    
    return $numeroPedido;
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/responsiveslides.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://code.jquery.com/ui/1.13.3/jquery-ui.js"></script>
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.3/themes/base/jquery-ui.css">
    
    <script>
        $(document).ready(function(){
            <?php if(isset($_SESSION["message"])): ?>
                alert('<?php echo $_SESSION["message"]; ?>');
                <?php unset($_SESSION["message"]); ?>
                
            <?php endif; ?>
        });
    </script>
    <script>
        $(document).ready(function() {
            $(".delete-product-btn").on("click", function() {
                var productId = $(this).data("id");
                $("#delete-confirm").data("id", productId).dialog("open");
            });

            $("#delete-confirm").dialog({
                autoOpen: false,
                resizable: false,
                height: "auto",
                width: 400,
                modal: true,
                buttons: {
                    "Sí": function() {
                        var productId = $(this).data("id");
                        $.post("carrito.php", { delete_product: true, product_id: productId }, function() {
                            location.reload();
                        });
                        $(this).dialog("close");
                    },
                    "No": function() {
                        $(this).dialog("close");
                    }
                }
            });
        });
    </script>

    <script type="text/javascript">
		$(document).ready(function(){
			$("#btnGuardarCliente").click(function(event){
				event.preventDefault();
				var datosCliente = {
					cliente_cedula: $("#cliente_cedula").val(),
					cliente_Nombre: $("#cliente_Nombre").val(),
					cliente_Apellido: $("#cliente_Apellido").val(),
					suscriptorZona: $("#suscriptorZona").val(),
					suscriptorSector: $("#suscriptorSector").val(),
					cliente_Telefono: $("#cliente_Telefono").val(),
					cliente_Celular: $("#cliente_Celular").val(),
					cliente_Email: $("#cliente_Email").val(),
				};

				$.ajax({
					url: 'ingresar_cliente.php',
					type: 'POST',
					data: datosCliente,
					dataType: 'json',
					success: function(response){
						if(response.status == "success"){
							alert('Datos guardados exitosamente');
						} else {
							alert('Error: ' + response.message);
						}
					},
					error: function(xhr, status, error) {
						alert('Error: ' + xhr.responseText);
					}
				});
			});	

			$("#suscriptorZona").change(function(){
				var zonaID = $(this).val();
				$.ajax({
					url: 'obtener_sectores.php',
					type: 'GET',
					data: { codigo : zonaID },
					success: function(response){
						var respuesta = '<option value="0">-- Escoja el sector donde vive</option>';
						respuesta += response;
						$("#suscriptorSector").html(respuesta).prop("disabled", false);
					}
				});
			});
		});
	</script>
</head>
<body>
<header>
    <nav class="navbar">
        <div class="navbar-container">
            <h1>Carrito de Compras</h1>
            <ul class="nav-menu">
                <li><a href="viveres.php">Inicio</a></li>
                <li><a href="#contacto">Contáctenos</a></li>
                <?php
                if (!empty($_SESSION["shopping_cart"])) {
                    $cart_count = array_sum(array_column($_SESSION["shopping_cart"], 'Cantidad'));
                ?>
                <li>
                    <a href="carrito.php"><img src="images/carrito.png" /> Carrito <span><?php echo $cart_count; ?></span></a>
                </li>
                <?php } ?>
            </ul>
        </div>
    </nav>
</header>
<div class="container">
    <h2>Detalle del Carrito de Compras</h2>
    <?php if (!empty($productos)): ?>
    <div style="display: flex;">
        <div style="width: 70%;">
            <div class="table-container" style="max-height: 400px; overflow-y: auto; border: 1px solid #ccc; padding: 10px;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Imagen</th>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Precio Unitario</th>
                            <th>Total Producto</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        $subtotalIVA15 = 0;
                        $subtotalIVA0 = 0;
                        $totalIVA = 0;
                        foreach ($productos as $producto):
                            $subtotal = $producto['Cantidad'] * $producto['Precio'];
                            $iva = ($producto['PagaIVA']) ? ($subtotal * 0.15) : 0;
                            $subtotaliva = $subtotal - $iva;
                            $totalProducto = $subtotal + $iva;
                            if ($producto['PagaIVA']) {
                                $subtotalIVA15 += $subtotal;
                            } else {
                                $subtotalIVA0 += $subtotal;
                            }
                            $totalIVA += $iva;
                        ?>
                        <tr>
                            <td><img src="<?php echo $producto['ImagenThumb']; ?>" alt="" width="50"></td>
                            <td><?php echo $producto['Nombre']; ?></td>
                            <td>
                                <form class="update-quantity-form" method="post" action="carrito.php">
                                    <input type="hidden" name="product_id" value="<?php echo $producto['ProductoID']; ?>">
                                    <center><input type="number" name="quantity" value="<?php echo $producto['Cantidad']; ?>" min="1"></center>
                                    <input type="submit" name="update_quantity" value="Actualizar">
                                </form>
                            </td>
                            <td><?php echo '$' . number_format($producto['Precio'], 2, '.', ''); ?></td>
                            <td><?php echo '$' . number_format($subtotal, 2, '.', ''); ?></td>
                            <td>
                                <button class="delete-product-btn" data-id="<?php echo $producto['ProductoID']; ?>">Eliminar</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div style="width: 30%; padding-left: 20px;">
            <div class="summary-box" style="border: 1px solid #ccc; padding: 10px;">
                <h3>Resumen</h3>
                <p>Subtotal IVA 15%: <?php echo '$' . number_format($subtotalIVA15, 2, '.', ''); ?></p>
                <p>Subtotal IVA 0%: <?php echo '$' . number_format($subtotalIVA0, 2, '.', ''); ?></p>
                <p>Subtotal: <?php echo '$' . number_format($subtotalIVA15 + $subtotalIVA0, 2, '.', ''); ?></p>
                <p>IVA 15%: <?php echo '$' . number_format($totalIVA, 2, '.', ''); ?></p>
                <p>Total: <?php echo '$' . number_format($subtotalIVA15 + $subtotalIVA0 + $totalIVA, 2, '.', ''); ?></p>
            </div>
            <div class="text-right">
                <a href="<?php echo isset($_SESSION['last_visited_page']) ? $_SESSION['last_visited_page'] : 'viveres.php'; ?>" class="btn btn-primary">Regresar a la Tienda</a>
                <button id="btnPagar" class="btn btn-primary">Pagar</button>
            </div>

        </div>
    </div>
    <div id="delete-confirm" title="Confirmar eliminación" style="display:none;">
        <p>¿Confirma que desea eliminar el producto?</p>
    </div>
    <?php else: ?>
    <p>No hay productos en el carrito.</p>
    <a href="<?php echo isset($_SESSION['last_visited_page']) ? $_SESSION['last_visited_page'] : 'viveres.php'; ?>" class="btn btn-primary">Regresar a la Tienda</a>
                <button id="btnPagar" class="btn btn-primary">Pagar</button>
    <?php endif; ?>
</div>

<div id="detallesPago" style="display: none; margin-top: 20px;">
    <button id="btnLugarEntrega" class="btn btn-primary" style="margin-bottom: 10px;">Lugar de entrega</button>
    <div id="lugarEntrega" style="display: none;">
        <select name="suscriptorZona" id="suscriptorZona" class="required" required>
            <option value="0">-- Escoja la zona donde vive</option>
            <?php
                $conn->query("SET NAMES utf8");
                $query = "SELECT `ZonaID`, `Nombre` FROM zona";
                $zonas = mysqli_query($conn, $query);
                while($row = mysqli_fetch_array($zonas)) {
                    echo '<option value="' . htmlspecialchars($row['ZonaID']) . '">' . htmlspecialchars($row['Nombre']) . '</option>';
                }
            ?>
        </select>
        <select name="suscriptorSector" id="suscriptorSector" class="required" disabled required>
            <option value="0">-- Escoja el sector donde vive</option>
        </select>
    </div>

    <button id="btnCostoEntrega" class="btn btn-primary" style="margin-bottom: 10px;">Costo de entrega</button>
    <div id="costoEntrega" style="display: none;">
        <!-- Aquí se mostrará el costo de entrega después de seleccionar la zona -->
    </div>

    <button id="btnDatosCliente" class="btn btn-primary" style="margin-bottom: 10px;">Datos del cliente para facturación</button>
    <div id="datosCliente" style="display: none; with: 50%">
        <form id="formCliente">
            <div class="form-group">
                <label for="cliente_Nombre">Nombre:</label>
                <input type="text" class="form-control" id="cliente_Nombre" name="cliente_Nombre" maxlength="40" pattern="[A-Za-z]+" required>
            </div>
            <div class="form-group">
                <label for="cliente_Apellido">Apellido:</label>
                <input type="text" class="form-control" id="cliente_Apellido" name="cliente_Apellido" maxlength="40" pattern="[A-Za-z]+" required>
            </div>
            <div class="form-group">
                <label for="cliente_Telefono">Teléfono:</label>
                <input type="text" class="form-control" id="cliente_Telefono" name="cliente_Telefono" maxlength="9" pattern="[0-9]+" required>
            </div>
            <div class="form-group">
                <label for="cliente_Celular">Celular:</label>
                <input type="text" class="form-control" id="cliente_Celular" name="cliente_Celular" maxlength="10" pattern="09[0-9]{8}" required>
            </div>
            <div class="form-group">
                <label for="cliente_Email">Email:</label>
                <input type="email" class="form-control" id="cliente_Email" name="cliente_Email" required>
            </div>
            <div class="form-group">
                <label for="cliente_cedula">Cédula/Ruc:</label>
                <input type="text" class="form-control" id="cliente_cedula" name="cliente_cedula" maxlength="13" pattern="[0-9]+" required>
            </div>
            <button id="btnGuardarCliente" class="btn btn-primary">Guardar Datos</button>
        </form>
    </div>

    <button id="btnFormaPago" class="btn btn-primary" style="margin-bottom: 10px;">Forma de pago</button>
    <div id="formaPago" style="display: none;">
       <select name="formaPago" id="formaPago" class="form-control" required>
                <option value="0">-- Seleccione una forma de pago --</option>
                <option value="1">Tarjeta de Crédito</option>
                <option value="2">Paypal</option>
                <option value="3">Transferencia Bancaria</option>
                <option value="4">Efectivo</option>
            </select>
        <button id="btnConfirmarPago" class="btn btn-primary">Confirmar pago</button>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#btnPagar').click(function() {
        $('#detallesPago').show();
        $('#btnPagar').prop('disabled', true);
    });

    $('#btnLugarEntrega').click(function() {
        $('#lugarEntrega').toggle();
    });

    $('#btnCostoEntrega').click(function() {
        $('#costoEntrega').toggle();
        var zona = $('#suscriptorZona').val();
        if (zona != '0') {
            var costo = 0;
            if (zona == 'Norte') costo = 3;
            if (zona == 'Centro') costo = 4;
            if (zona == 'Sur') costo = 5;
            if (zona == 'Valles') costo = 4;
            $('#costoEntrega').html('Costo de entrega: $' + costo + ' (incl. IVA)');
        }
    });

    $('#btnDatosCliente').click(function() {
        $('#datosCliente').toggle();
    });

    $('#btnFormaPago').click(function() {
        $('#formaPago').toggle();
    });
});
</script>
<script>
$(document).ready(function() {
    // Botón Confirmar pago
    $('#btnConfirmarPago').click(function() {
        var totalPedido = <?php echo $totalPedido; ?>;
        var mensaje = `El valor del pedido es de $${totalPedido}. ¿Desea confirmar el pago?`;
        
        // Mostrar el diálogo jQuery UI Dialog
        $("#dialog-confirm").html(mensaje);
        $("#dialog-confirm").dialog({
            resizable: false,
            height: "auto",
            width: 400,
            modal: true,
            buttons: {
                "Aceptar": function() {
                    $(this).dialog("close");
                    var numeroPedido = <?php echo guardarPedidoEnBD($productos, $totalPedido); ?>;
                    alert(`Su pedido ha sido registrado con éxito. El No. de pedido es ${numeroPedido}.`);
                    // Redireccionar al cliente a la página principal
                    window.location.href = '<?php echo $ultimaCategoria; ?>';

                    // Limpiar variables de sesión
                    // Aquí deberías implementar el código para limpiar las variables de sesión utilizadas
                },
                "Cancelar": function() {
                    $(this).dialog("close");
                    alert('El pago fue cancelado.');
                }
            }
        });
    });
});
</script>

<!-- Diálogo jQuery UI Dialog -->
<div id="dialog-confirm" title="Confirmar pago"></div>
</body>
</html>
